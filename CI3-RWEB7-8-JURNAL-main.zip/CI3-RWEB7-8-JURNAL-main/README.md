# CI3-RWEB7-JURNAL
 Code Igniter 3 CRUD Jurnal
