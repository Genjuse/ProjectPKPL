<!-- <footer class="bg-light text-center text-lg-start">
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2022 Copyright:
    <a class="text-dark" href="https://krisdewa.my.id/">krisdewa.my.id</a>
  </div>
</footer> -->

</body>

</html>